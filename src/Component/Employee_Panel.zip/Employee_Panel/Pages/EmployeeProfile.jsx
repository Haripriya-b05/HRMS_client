import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { setEmployeeData } from "../../../Features/Employee/EmployeeSlice";

export default function EmployeeProfile() {
  const dispatch = useDispatch();
  const employees = useSelector((state) => state.employee.employeeData || []);
  const current = employees.length ? employees[0] : null;

  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    department: "",
    role: "",
    address: "",
    avatar: "",
  });
  const [preview, setPreview] = useState(null);

  useEffect(() => {
    if (current) {
      setForm({
        name: current.name || "",
        email: current.email || "",
        phone: current.phone || "",
        department: current.department || "",
        role: current.role || "",
        address: current.address || "",
        avatar: current.avatar || "",
      });
      setPreview(current.avatar || null);
    }
  }, [current]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((s) => ({ ...s, [name]: value }));
  };

  const handleFile = (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setPreview(reader.result);
      setForm((s) => ({ ...s, avatar: reader.result }));
    };
    reader.readAsDataURL(file);
  };

  const handleSave = (e) => {
    e.preventDefault();
    const updated = [...employees];
    if (updated.length) {
      updated[0] = { ...updated[0], ...form };
    } else {
      updated.push(form);
    }
    dispatch(setEmployeeData(updated));
    alert("Profile saved");
  };

  return (
    <div>
      <div className="min-h-screen bg-gray-50 p-6">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-semibold text-gray-800">My Profile</h1>
            <div className="text-sm text-gray-500">Dashboard / Profile</div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {/* Sidebar summary */}
            <aside className="md:col-span-1 bg-white rounded-lg shadow py-6 px-5">
              <div className="flex items-center gap-4">
                {preview ? (
                  <img
                    src={preview}
                    alt="avatar"
                    className="w-28 h-28 rounded-md object-cover shadow-sm"
                  />
                ) : (
                  <div className="w-28 h-28 rounded-md bg-indigo-50 flex items-center justify-center text-indigo-400 text-sm">
                    No Image
                  </div>
                )}

                <div>
                  <div className="text-lg font-medium text-gray-800">
                    {form.name || "—"}
                  </div>
                  <div className="text-sm text-gray-500">
                    {form.role || "Employee"}
                  </div>
                  <div className="text-xs text-gray-400 mt-1">
                    {form.email || ""}
                  </div>
                </div>
              </div>

              <div className="mt-6 grid grid-cols-2 gap-3">
                <div className="bg-gray-50 rounded-md p-3 text-center">
                  <div className="text-sm font-semibold text-gray-800">
                    {form.department || "—"}
                  </div>
                  <div className="text-xs text-gray-500">Department</div>
                </div>
                <div className="bg-gray-50 rounded-md p-3 text-center">
                  <div className="text-sm font-semibold text-gray-800">
                    {form.phone || "—"}
                  </div>
                  <div className="text-xs text-gray-500">Phone</div>
                </div>
              </div>

              <div className="mt-5">
                <button
                  type="button"
                  onClick={() =>
                    document
                      .getElementById("profileForm")
                      ?.scrollIntoView({ behavior: "smooth" })
                  }
                  className="w-full inline-flex items-center justify-center gap-2 px-3 py-2 bg-green-500 text-white text-sm rounded-md shadow-sm hover:bg-green-600"
                >
                  Edit Profile
                </button>
              </div>
            </aside>

            {/* Main form */}
            <main className="md:col-span-3">
              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-lg font-semibold text-gray-800 mb-4">
                  Account Details
                </h2>

                <form
                  id="profileForm"
                  onSubmit={handleSave}
                  className="space-y-6"
                >
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Name
                      </label>
                      <input
                        name="name"
                        value={form.name}
                        onChange={handleChange}
                        className="block w-full rounded-md border-gray-200 shadow-sm focus:ring-2 focus:ring-indigo-200 px-3 py-2"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Email
                      </label>
                      <input
                        name="email"
                        value={form.email}
                        onChange={handleChange}
                        className="block w-full rounded-md border-gray-200 shadow-sm focus:ring-2 focus:ring-indigo-200 px-3 py-2"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Phone
                      </label>
                      <input
                        name="phone"
                        value={form.phone}
                        onChange={handleChange}
                        className="block w-full rounded-md border-gray-200 shadow-sm focus:ring-2 focus:ring-indigo-200 px-3 py-2"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Department
                      </label>
                      <input
                        name="department"
                        value={form.department}
                        onChange={handleChange}
                        className="block w-full rounded-md border-gray-200 shadow-sm focus:ring-2 focus:ring-indigo-200 px-3 py-2"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Role
                      </label>
                      <input
                        name="role"
                        value={form.role}
                        onChange={handleChange}
                        className="block w-full rounded-md border-gray-200 shadow-sm focus:ring-2 focus:ring-indigo-200 px-3 py-2"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Avatar
                      </label>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleFile}
                        className="block w-full text-sm text-gray-600"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Address
                    </label>
                    <textarea
                      name="address"
                      value={form.address}
                      onChange={handleChange}
                      className="block w-full rounded-md border-gray-200 shadow-sm focus:ring-2 focus:ring-indigo-200 px-3 py-2"
                    />
                  </div>

                  <div className="flex items-center justify-end gap-3">
                    <button
                      type="button"
                      onClick={() => {
                        /* reset or cancel logic */
                      }}
                      className="px-4 py-2 rounded-md bg-gray-100 text-sm text-gray-700 hover:bg-gray-200"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-2 rounded-md bg-indigo-600 text-white text-sm hover:bg-indigo-700"
                    >
                      Save changes
                    </button>
                  </div>
                </form>
              </div>
            </main>
          </div>
        </div>
      </div>
    </div>
  );
}